# coding=utf-8
from teop.consts import TaskResultKeysConsts, JobResultKeysConsts


class TaskResult(object):
    def __init__(self, res):
        self.res = res
        self.job_id = res[TaskResultKeysConsts.job_id]
        self.target_ip = res[TaskResultKeysConsts.target_ip]
        self.start_time = res[TaskResultKeysConsts.start_time]
        self.end_time = res[TaskResultKeysConsts.end_time]
        self.status = res[TaskResultKeysConsts.status]
        self.module = res[TaskResultKeysConsts.module]
        self.command = res[TaskResultKeysConsts.command]
        self.std_out = res[TaskResultKeysConsts.std_out]
        self.std_err = res[TaskResultKeysConsts.std_err]
        self.msg = res[TaskResultKeysConsts.msg]

    def __getattr__(self, item):
        if item in self.res:
            return self.res[item]
        raise AttributeError("'%s' object has no attribute '%s'" % (self.__class__.__name__, item))


class JobResult(object):
    def __init__(self, res):
        self.res = res
        self.job_id = res[JobResultKeysConsts.job_id]
        self.name = res[JobResultKeysConsts.name]
        self.content = res[JobResultKeysConsts.content]
        self.create_time = res[JobResultKeysConsts.create_time]
        self.start_time = res[JobResultKeysConsts.start_time]
        self.end_time = res[JobResultKeysConsts.end_time]
        self.status = res[JobResultKeysConsts.status]
        self.source = res[JobResultKeysConsts.source]
        self.terminator = res[JobResultKeysConsts.terminator]
        self.node_host_name = res[JobResultKeysConsts.node_host_name]
        self.unclaim_hosts = res[JobResultKeysConsts.unclaim_hosts]
        self.task_result_list = None

    def __getattr__(self, item):
        if item in self.res:
            return self.res[item]
        raise AttributeError("'%s' object has no attribute '%s'" % (self.__class__.__name__, item))
