# coding=utf-8
import re
import uuid
import platform


class BaseDescriptor(object):
    def __init__(self):
        if platform.python_version() < '3.6':
            self.name = str(uuid.uuid4()) + self.__class__.__name__
    
    def __get__(self, instance, owner):
        if instance is None:
            return self
        return instance.__dict__[self.name]
    
    def __set_name__(self, owner, name):
        self.name = name
    
    def _bind_value(self, instance, value):
        instance.__dict__[self.name] = value


class SingleLayerDict(BaseDescriptor):
    _valid_value_type = (int, str, bool)

    def __set__(self, instance, value):
        assert isinstance(value, dict), 'Only dictionary are allowed to be set.'
        for k, v in value.items():
            if type(v) not in self._valid_value_type:
                raise Exception('Invalid data:{}, the value can only be a int,str or bool'.format({k: v}))
        self._bind_value(instance, value)


class NaturalNumber(BaseDescriptor):
    
    def __set__(self, instance, value):
        assert isinstance(value, int) and value >= 0, 'Only non-negative integer are allowed to be set.'
        self._bind_value(instance, value)


class IpAddress(BaseDescriptor):
    _ipv4_pattern = r"^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$"

    @classmethod
    def _is_ipv4_address(cls, s):
        assert isinstance(s, str)
        return bool(re.match(cls._ipv4_pattern, s))

    def __set__(self, instance, value):
        assert self._is_ipv4_address(value), '{} is not a ipv4 address.'.format(value)
        self._bind_value(instance, value)


class AnsibleModule(BaseDescriptor):
    __valid_modules = [
        'shell', 'script', 'command', 'copy', 'ping', 'fetch', 'archive', 'unarchive', 'replace', 'file', 'synchronize',
        'uri', 'ora_tbs', 'ora_instance', 'ora_general', 'ora_user', 'ora_listener', 'ora_sys_params', 'ora_tbs_resize',
        'ora_pdb_sh', 'ora_srvctl_service_sh', 'port_check',
        'win_shell', 'win_command',  'win_copy',  'win_service',  'win_ping',
    ]

    def __set__(self, instance, value):
        assert value in self.__valid_modules, 'Invalid module:{}.'.format(value)
        self._bind_value(instance, value)
