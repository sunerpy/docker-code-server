# coding=utf-8
from teop.interact import interaction, sign

from teop.entity.job import TeopJob
from teop.version_check import pre_run_check
from teop.consts import SignConsts

pre_run_check()


def set_key_path(key_path):
    import os
    assert os.path.exists(key_path), '%s  not found, please check the file!' % key_path
    SignConsts.path = key_path



class TeopApp(object):
    def __init__(self, gateway, system_name):
        '''
        :param gateway: str, teop服务器的网关地址
        :param system_name: str, 使用本sdk的系统名称
        使用teop sdk的系统必须在运维作业平台上注册并审核通过，将密钥文件下载后放到系统根目录
        '''
        self.gateway = gateway
        self.system_name = system_name

    def create_job(self, hosts, tasks, name, domain_key='rsp', sharding=0, become_user=''):
        '''
        :param hosts: List(Host), 由Host实例构成的列表
        :param tasks: List(Task), 由Task实例构成的列表
        :param name: str, 即将创建的job的名字
        :param domain_key: str, 该作业指向的域名 todo: 去除默认参数，改为必填参数
        :param sharding: int, 是否进行作业分片执行，0 为不分片， 1为分片 todo: 去除默认参数，改为必填参数
        :return: TeopJob, TeopJob实例
        '''
        # 默认参数
        teop_job = TeopJob(hosts, tasks, self.system_name, name, domain_key, sharding, become_user)
        return teop_job

    def send_job(self, teop_job, timeout=60):
        '''
        :param teop_job: TeopJob, TeopJob实例
        :return: bool, 发送成功或者是失败
        发送成功只是代表这个任务已经被运维作业平台接收，具体的执行时间和执行过程视任务内容而定
        任务结束后，运维作业平台将会回调本系统所注册的回调接口，以告知本任务执行完毕
        '''
        signature = sign.create_signature(teop_job.source + teop_job.job_id)
        is_succeed = interaction.send(self.gateway, teop_job.structure, signature, timeout=timeout)
        return is_succeed

    def send_job_sync(self, teop_job, timeout=-1):
        signature = sign.create_signature(teop_job.source + teop_job.job_id)
        job_result = interaction.send_sync(self.gateway, teop_job.structure, signature, timeout=timeout)
        return job_result

    def terminate_job(self, job_id, timeout=60):
        '''
        :param job_id: str, teop_job的唯一标识
        :return: bool, 终止信息发送成功或是失败
        '''
        signature = sign.create_signature(self.system_name + job_id)
        is_succeed = interaction.terminate(self.gateway, self.system_name, job_id, signature, timeout=timeout)
        return is_succeed

    def fetch_result(self, job_id, timeout=60):
        '''
        :param job_id: str, TeopJob的唯一标识
        :return: JobResult, JobResult实例
        '''
        job_result = interaction.get_job_result(self.gateway, job_id, timeout=timeout)
        if not job_result:
            return None
        tasks_result = interaction.get_tasks_result(self.gateway, job_id, timeout=timeout)
        job_result.task_result_list = tasks_result
        return job_result

