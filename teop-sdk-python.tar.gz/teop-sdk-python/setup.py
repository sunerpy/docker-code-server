# coding=utf-8
from setuptools import setup, find_packages

setup(
    name='teop',
    version='1.1.0',
    # url=
    long_description=open('README.md', encoding='utf-8').read(),
    packages=find_packages(),
    install_requires=['requests', 'cryptography'],
    # # 依赖包默认从pypi仓库中下载，也可以从指定链接下载依赖
    # dependency_links=[
    #     'http://128.199.101.80:8000/simple/requests',
    #     'http://128.199.101.80:8000/simple/cryptography',
    # ]
)