# coding=utf-8
import requests
import json
try:
    from urllib.parse import urljoin
except ImportError:
    from urlparse import urljoin

from teop.consts import UrlConsts, ReqResConsts
from teop.interact.result import JobResult, TaskResult
from teop import logger



def send(gateway, job_structure, signature, timeout=60):
    url = urljoin(gateway, UrlConsts.add_job)
    res = requests.post(url=url, json=job_structure, headers={'Content-type': 'application/json', 'signature': signature}, timeout=timeout)
    if res.status_code != 200:
        msg = 'the response code is %s, the response content is %s ' % (res.status_code, res.content.decode('unicode_escape'))
        logger.info(msg)
        raise Exception(msg)
    try:
        result = json.loads(res.content)['result']
    except:
        msg = 'the response code is %s, the response content is %s ' % (
        res.status_code, res.content.decode('unicode_escape'))
        logger.info(msg)
        raise Exception(msg)
    return result == ReqResConsts.add_job_succeed


def send_sync(gateway, job_structure, signature, timeout=-1):
    url = urljoin(gateway, UrlConsts.add_job_sync)
    if timeout <= 0:
        res = requests.post(url=url, json=job_structure,
                        headers={'Content-type': 'application/json', 'signature': signature})
    else:
        res = requests.post(url=url, json=job_structure,
                            headers={'Content-type': 'application/json', 'signature': signature}, timeout=timeout)
    if res.status_code != 200:
        msg = 'the response code is %s, the response content is %s ' % (res.status_code, res.content.decode('unicode_escape'))
        logger.info(msg)
        raise Exception(msg)
    try:
        job_tasks_result = json.loads(res.content)['result']
        task_result_data = job_tasks_result.pop('tasks_data')
        job_result_data = job_tasks_result
        job_result_obj = JobResult(job_result_data)
        task_result_obj = [TaskResult(task_info) for task_info in task_result_data] if task_result_data else []
        job_result_obj.task_result_list = task_result_obj
        return job_result_obj
    except:
        msg = 'the response code is %s, the response content is %s ' % (
        res.status_code, res.content.decode('unicode_escape'))
        logger.info(msg)
        raise Exception(msg)

def terminate(gateway, job_source, job_id, signature, timeout=180):
    url = urljoin(gateway, UrlConsts.terminate_job.format(job_id))
    # the termiante api of teop servie allowed method change from 'patch' to 'post
    res = requests.post(url=url, headers={'signature': signature}, json={'terminator': job_source}, timeout=timeout)
    # res = requests.patch(url=url, headers={'signature': signature}, json={'terminator': job_source})
    if res.status_code != 200:
        logger.info('the response code is %s, the response content is %s ' % (res.status_code, res.content.decode('unicode_escape')))
        raise Exception
    try:
        result = json.loads(res.content)['result']
    except:
        logger.warning('the response code is %s, the response content is %s ' % (res.status_code, res.content.decode('unicode_escape')))
        raise
    return result == ReqResConsts.add_termination_succeed


def get_job_result(gateway, job_id, timeout=60):
    url = urljoin(gateway, UrlConsts.get_job.format(job_id))
    res = requests.get(url=url, timeout=timeout)
    if res.status_code != 200:
        logger.info('the response code is %s, the response content is %s ' % (res.status_code, res.content.decode('unicode_escape')))
        raise Exception
    try:
        result = json.loads(res.content)['result']
    except:
        logger.warning('the response code is %s, the response content is %s ' % (res.status_code, res.content.decode('unicode_escape')))
        raise
    return JobResult(result) if result else None


def get_tasks_result(gateway, job_id, timeout=60):
    url = urljoin(gateway, UrlConsts.get_tasks.format(job_id))
    res = requests.get(url=url, timeout=timeout)
    if res.status_code != 200:
        logger.info('the response code is %s, the response content is %s ' % (res.status_code, res.content.decode('unicode_escape')))
        raise Exception
    try:
        result = json.loads(res.content)['result']
    except:
        logger.warning('the response code is %s, the response content is %s ' % (res.status_code, res.content.decode('unicode_escape')))
        raise
    return [TaskResult(task_info) for task_info in result] if result else []