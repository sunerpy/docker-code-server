# coding=utf-8
from teop.entity.description import SingleLayerDict, NaturalNumber, IpAddress, AnsibleModule


class Host(object):
    ip_addr = IpAddress()
    vars = SingleLayerDict()

    def __init__(self, ip_addr, vars=None):
        self.ip_addr = ip_addr
        self.vars = vars if vars else {}

    @property
    def structure(self):
        return {
            'host_ip': self.ip_addr,
            'vars': self.vars
        }


class Task(object):
    module = AnsibleModule()
    time_out = NaturalNumber()
    args = SingleLayerDict()
    should_delegate_to_localhost = {'ora_tbs', 'ora_general', 'ora_user', 'ora_sys_params', 'ora_tbs_resize'}

    def __init__(self, module, args, time_out=0, **kwargs):
        self.module = module
        if isinstance(args, str):
            args = {'_raw_params': args}
        self.args = args
        self.time_out = time_out
        self.__kwargs = kwargs

    @property
    def structure(self):
        struct = {
            'action': {
                'module': self.module,
                'args': self.args,
            },
            'task_timeout': self.time_out
        }
        struct.update(self.__kwargs)
        if self.module in self.should_delegate_to_localhost:
            struct.update(dict(delegate_to='localhost'))
        return struct
