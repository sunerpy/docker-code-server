import teop.application
from teop.entity.base import Host, Task


# 发布作业的示例代码
# gateway指向提供teop服务的网关，system_name标识自身的系统名
app = teop.application.TeopApp(gateway='http://128.195.0.49:8000', system_name='lihao')

# 一个job可以包含多个host和task，它们之间构成的笛卡尔积的每个元素，每个元素代表一个子任务
hosts = [
        # 构建Host对象
        # ip_addr参数接收一个字符串，即目标机器的ip地址
        # vars参数是可选的，它接收一个字典，每个键值对和Task对象的args是对应的
        Host(
            ip_addr='128.200.23.224',
            vars={'sleep_time': 10}
        ),
        Host(
            ip_addr='128.199.113.183',
            vars={'sleep_time': 20}
        ),
]

tasks = [
        # 构建Task对象
        # module参数接收一个字符串，不同的module会有不同的使用方式，以下示例中使用shell,args只需传入一个shell命令即可
        # args参数仅在module是shell/script时接收一个字符串，使用其他module，则需要接收一个字典）
        # time_out参数接收一个正整数，它代表该task的最大执行时间，超过这个值，则task会被强制结束
        Task(
            module='shell',
            args='hostname & sleep {{sleep_time}}', # sleep_time由Host对象设置，每个Host去执行该条shell命令时，都可以自定义睡眠时间
            time_out=200
        ),
        Task(
            module='shell',
            args='ifconfig',
            time_out=200
        ),
]


# 发布job
job = app.create_job(hosts=hosts, tasks=tasks, name='test_job') # create_job方法返回一个TeopJob对象
print(job.job_id)   # 每个TeopJob对象的job_id属性都是由uuid生成
is_succeed = app.send_job(job)  # send_job方法返回一个bool值，代表此次发布作业是否成功
print(is_succeed)

# 发布的job被teop执行完后，可以主动调用以下方法查看job的执行结果
# 当然也可以在执行完之前去查看，但查看到的信息会是不完整的
# 实际上，teop执行完job之后会发起一次回调，在回调接口中，可以直接取到结果信息
# 因此，并不建议在发送job之后主动查看job的执行结果
job_res = app.fetch_result(job_id='xxx') # fetch_result方法返回一个JobResult对象
print(job_res.res)  # JobResult对象的res属性返回一个字典，它包含了job的执行信息
print(job_res.status, job_res.name) # JobResult对象还具有status、name等其他属性
trl = job_res.task_result_list # task_result_list属性返回一个由TaskResult对象组成的列表
first_task_result = trl[0]
print(first_task_result.res, first_task_result.status, first_task_result.target_ip) # TaskResult对象的使用方式和JobResult对象时类似的

# teop_job是异步执行的，当teop执行完job后，会向发送该job的系统发起一次回调
# 以Django写的回调接口为例
from django.http import HttpResponse
from teop.interact.callback import CallbackHandler, IResultHandler

# 实现IRresultHandler接口以执行自定义的业务逻辑，它只具有一个抽象方法：process_job_result，重写它即可
class CustomWork(IResultHandler):
    def process_job_result(self, result):
        # result是一个JobResult对象，通过result.job_id可以得知此次回调所代表的是哪一个job已经结束
        # 在这里写自定义的业务逻辑，关于该回调所对应的job的执行信息，都可以通过JobResult对象的各个属性进行获取
        pass

custom_work = CustomWork()

def teop_callback_view(request):
    # 在这里实例化CallbackHandler，它会解析teop发过来的回调信息并封装好一个JobResult对象
    callback_handler = CallbackHandler(request.data, gateway='http://128.195.0.49:8000')
    # 将custom_work实例传给callback_handler的handle方法并调用，即可执行自定义的业务逻辑
    # 这里建议做异步处理，因为进入到这行代码，说明teop发起的回调已经成功了
    # 但如果handle的执行过程出错，Django返回的http状态码将会是500或其他不正常的值，此时teop将会认为回调失败，但实际上回调已经成功了
    # 另一方面，teop希望回调通知成功后，能够尽快获得Response，而不是等待handle过程结束了，才能获得Response
    # 当然，如果handle过程处理较快且抛出的异常能够被及时处理，或者不关心teop能否准确记录此次作业的回调状态，那么就忽略这个建议吧
    callback_handler.handle(custom_work)
    return HttpResponse('响应信息能够表示本系统已收到回调即可，内容不作限定')