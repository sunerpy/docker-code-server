# coding=utf-8
import json
from teop.consts import CallbackKeys
from teop.interact import interaction
from abc import ABCMeta, abstractmethod
from six import with_metaclass


class CallbackHandler(object):
    '''
    在回调接口收到回调信息时，创建这个类的实例
    它会更新本地数据库中的job的状态
    '''
    def __init__(self, callback_data, gateway):
        '''
        :param callback_data: str, 回调接口中视图函数收到的request.data
        :param gateway: str, teop服务器的网关地址
        '''
        self.callback_info = json.loads(callback_data)
        self.gateway = gateway
        self.job_id = self.callback_info[CallbackKeys.job_id]
        self.job_status = self.callback_info[CallbackKeys.job_status]

    def __fetch_result(self):
        '''
        :param job_id: str, TeopJob的唯一标识
        :return: JobResult, JobResult实例
        '''
        job_result = interaction.get_job_result(self.gateway, self.job_id)
        if not job_result:
            return None
        tasks_result = interaction.get_tasks_result(self.gateway, self.job_id)
        job_result.task_result_list = tasks_result
        return job_result

    def handle(self, i_result_handler=None):
        '''
        视图函数收到回调消息后，实例化Handler，并调用handle方法
        以更新本地数据库和从teop服务器抓取任务结果
        可以将已实现的IResultHandler接口传入该方法，以执行自定义的业务逻辑
        '''
        if i_result_handler:
            i_result_handler.process_job_result(self.__fetch_result())


class IResultHandler(with_metaclass(ABCMeta)):
    @abstractmethod
    def process_job_result(self, result):
        '''
        :param result: JobResult实例
        '''
        pass

