# coding=utf-8

from teop.consts import SignConsts
from teop import logger
import os
import itertools
import platform


def version_comparision(version_str, another):
    v = list(map(lambda s: int(s), version_str.split('.')))
    another_v = list(map(lambda s: int(s), another.split('.')))
    return list(itertools.starmap(lambda v_num, another_v_num: v_num - another_v_num, zip(v, another_v)))


def pre_run_check():
    assert platform.python_version() > '2.2', 'python_version is too old: %s' % platform.python_version()
    assert os.path.exists(SignConsts.path), '%s  not found,"teop.key" is required!' % SignConsts.path
    logger.info('sdk pre_run_check passed')