# coding=utf-8
class SignConsts(object):
    path = 'teop.key'


class VersionConsts(object):
    version = '1.0.0'


class UrlConsts(object):
    micro_service = 'teop/'
    add_job = micro_service + 'job/service/'
    add_job_sync = micro_service + 'sync_job/sync_service/'
    terminate_job = micro_service + 'job/service/{}/'
    get_job = micro_service + 'job/service/{}/'
    get_tasks = micro_service + 'job/service/{}/tasks/'


class ReqResConsts(object):
    add_job_succeed = 'ADD_OK'
    add_termination_succeed = 'ADD_OK'


class TaskResultKeysConsts(object):
    job_id = 'job_id'
    target_ip = 'task_target_ip'
    command = 'task_command'
    start_time = 'task_start_time'
    end_time = 'task_end_time'
    std_out = 'std_out'
    std_err = 'std_err'
    msg = 'msg'
    status = 'task_status'
    module = 'ansible_module'


class JobResultKeysConsts(object):
    job_id = 'job_id'
    name = 'job_name'
    content = 'job_content'
    create_time = 'job_create_time'
    start_time = 'job_start_time'
    end_time = 'job_end_time'
    status = 'job_status'
    source = 'job_source'
    terminator = 'terminator'
    node_host_name = 'node_host_name'
    unclaim_hosts = 'unclaim_hosts'


class CallbackKeys(object):
    job_id = 'job_id'
    job_status = 'job_status'


class VersionUpdateInfo(object):
    pass
    # records = {
    #     '1.0.1': 'change callback function...',
    #     '1.0.2':  'change ansible module limits',
    #     '1.0.3': 'compatible for py2 and py3',
    #     '1.0.4': 'add support for win modules, add method for setting pri_key_file_path',
    #     '1.0.5': 'remove support for sqlite',
    # }