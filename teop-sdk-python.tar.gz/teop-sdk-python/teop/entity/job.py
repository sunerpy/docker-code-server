# coding=utf-8
import uuid


class TeopJob(object):
    def __init__(self, hosts, tasks, source, name, domain_key, sharding, become_user, become=True, become_method='su'):
        self.hosts = hosts
        self.tasks = tasks
        self.source = source
        self.name = name
        self.domain_key = domain_key
        # 强制分片
        self.sharding = 1
        self._job_id = str(uuid.uuid4())
        self.become = become
        self.become_method = become_method
        self.become_user = become_user
        self.level = 'USING'

    def set_level(self, level):
        self.level = level

    @property
    def job_id(self):
        return self._job_id

    @property
    def target_ip(self):
        return list(map(lambda h: h.structure, self.hosts))

    @property
    def commands(self):
        return list(map(lambda t: t.structure, self.tasks))

    @property
    def structure(self):
        return {
            'target_ip': self.target_ip,
            'commands': self.commands,
            'job_source': self.source,
            'job_name': self.name,
            'job_id': self.job_id,
            'domain_key': self.domain_key,
            'sharding': self.sharding,
            'become_arg': {
                'become': self.become,
                'become_method': self.become_method,
                'become_user': self.become_user
            },
            'level': self.level or 'USING'
        }
