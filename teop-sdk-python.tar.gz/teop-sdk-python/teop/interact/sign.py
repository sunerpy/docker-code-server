# coding=utf-8
# from Crypto.Hash import SHA
# from Crypto.Signature import PKCS1_v1_5 as Signature_pkcs1_v1_5
# from Crypto.PublicKey import RSA
# import base64
#
#
# def create_signature(msg, sign_file='teop.key'):
#     with open(sign_file) as f:
#         pri_key = f.read()
#         rsakey = RSA.importKey(pri_key)
#         signer = Signature_pkcs1_v1_5.new(rsakey)
#         digest = SHA.new()
#         if isinstance(msg, str):
#             msg = msg.encode()
#         digest.update(msg)
#         sign = signer.sign(digest)
#         signature = base64.b64encode(sign)
#         return signature


from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding
import base64
from teop.consts import SignConsts


def create_signature(msg):
    with open(SignConsts.path, 'rb') as f:
        key_data = f.read()
    pri_key = serialization.load_pem_private_key(
            data=key_data,
            password=None,
            backend=default_backend()
            )
    if isinstance(msg, str):
        msg = msg.encode()
    signature = pri_key.sign(
            msg,
            padding.PKCS1v15(),
            # 这个SHA1决定了签名结果，即SHA1签名能被SHA1验证，不能被SHA256验证，反之亦然
            hashes.SHA1(),
            # hashes.SHA256(),
            )
    return base64.b64encode(signature)
